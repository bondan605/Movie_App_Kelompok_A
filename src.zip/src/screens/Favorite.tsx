import React from "react";
import { View, Text } from "react-native";

export default function Favorite(): JSX.Element {
  return (
    <View>
      <Text>Favorite</Text>
    </View>
  );
}
