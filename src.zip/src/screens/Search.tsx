import React from "react";
import { View, Text } from "react-native";

export default function Search(): JSX.Element {
  return (
    <View>
      <Text>Search</Text>
    </View>
  );
}
